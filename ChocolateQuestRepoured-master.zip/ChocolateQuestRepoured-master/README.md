# ChocolateQuestRepoured
CQ Repoured is a rewrite of the classic Chocolate Quest and Better Dungeons Minecraft mods, for Minecraft version 1.12.2.

To use, please head to our Jenkins and download the latest stable build
## Links

[Discord](https://discord.gg/StWzzFw)

[VERY WIP Wiki](https://cq-repoured.wikia.com/wiki/Chocolate_Quest_Re-poured_Wiki)

[Jenkins](http://jenkins.thechocolatequest.gq:8080/job/TheChocolateQuest)
