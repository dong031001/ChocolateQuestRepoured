package com.teamcqr.chocolatequestrepoured.util;

public interface IHasModel 
{
	public void registerModels();
}